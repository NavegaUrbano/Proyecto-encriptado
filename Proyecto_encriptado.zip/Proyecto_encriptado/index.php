<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.bundle.min.js"></script>
    <style>
        .invalid-feedback {
            color: #FFA500; /* Cambia el rojo a un color más amigable */
            display: none;
        }
        input:invalid + .invalid-feedback {
            display: block;
        }
    </style>
    <script>
        function validarFormulario() {
            var username = document.getElementById("username");
            var password = document.getElementById("password");
            var nip = document.getElementById("nip");

            var nipRegex = /^\d{3}[a-zA-Z]{1}$/;
            var contrasenaRegexMayus = /[A-Z]/;
            var contrasenaRegexMinus = /[a-z]/;
            var contrasenaRegexNumero = /\d/;
            var contrasenaRegexEspecial = /[!$%^&*()_+{}\[\]|:<>?]/; // Expresión corregida

            // Validar NIP
            if (!nipRegex.test(nip.value)) {
                nip.setCustomValidity("El NIP debe tener 3 números y una letra.");
            } else {
                nip.setCustomValidity("");  // Restablece la validación
            }

            // Validar Contraseña y dar feedback específico
            var mensajesError = [];
            if (!contrasenaRegexMayus.test(password.value)) {
                mensajesError.push("Falta una mayúscula.");
            }
            if (!contrasenaRegexMinus.test(password.value)) {
                mensajesError.push("Falta una minúscula.");
            }
            if (!contrasenaRegexNumero.test(password.value)) {
                mensajesError.push("Falta un número.");
            }
            if (!contrasenaRegexEspecial.test(password.value)) {
                mensajesError.push("Falta un carácter especial no común.");
            }

            if (mensajesError.length > 0) {
                password.setCustomValidity(mensajesError.join(" "));
            } else {
                password.setCustomValidity("");  // Restablece si todo está bien
            }

            // Mostrar mensajes específicos
            return nip.reportValidity() && password.reportValidity();
        }
    </script>
</head>
<body>
    <div class="container mt-5">
        <h2>Registro de Usuario</h2>
        <form action="php/registro.php" method="post" onsubmit="return validarFormulario();">
            <div class="mb-3">
                <label for="username" class="form-label">Usuario:</label>
                <input type="text" id="username" name="username" class="form-control" required>
                <div class="invalid-feedback">El campo usuario es obligatorio.</div>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Contraseña:</label>
                <input type="password" id="password" name="password" class="form-control" required>
                <div class="invalid-feedback" id="passwordFeedback">
                    <!-- Mensajes específicos de la contraseña aparecerán aquí -->
                </div>
            </div>
            <div class="mb-3">
                <label for="nip" class="form-label">NIP:</label>
                <input type="text" id="nip" name="nip" class="form-control" required>
                <div class="invalid-feedback">
                    El NIP debe tener 3 números y una letra (ej. 579a).
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Registrarse</button>
        </form>
    </div>
</body>
</html>
