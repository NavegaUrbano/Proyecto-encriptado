<?php
$servername = "localhost";  // Dirección del servidor
$username = "root";  // Usuario de la base de datos
$password = "";  // Contraseña de la base de datos
$dbname = "usuarios_bd";  // Nombre de la base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['username'];
    $contrasena = $_POST['password'];
    $nip = $_POST['nip'];

    // Validaciones
    if (!preg_match('/^\d{3}[a-zA-Z]{1}$/', $nip)) {
        echo "El NIP debe tener 3 números y una letra.";
        exit();
    }

    if (!preg_match('/[A-Z]/', $contrasena) || !preg_match('/[a-z]/', $contrasena) || 
        !preg_match('/\d/', $contrasena) || !preg_match('/[!$%^&*()_+{}|:<>?]/', $contrasena)) {
        echo "La contraseña no cumple con los requisitos.";
        exit();
    }

    // Seleccionar un carácter aleatorio del NIP para el desplazamiento
    $indexAleatorio = rand(0, strlen($nip) - 1);
    $caracterAleatorio = $nip[$indexAleatorio];
    $desplazamiento = obtenerDesplazamiento($caracterAleatorio);

    // Encriptar la contraseña con el desplazamiento seleccionado
    $contrasenaEncriptada = encriptarContrasena($contrasena, $desplazamiento);
    
    // Encriptar el NIP, usando el algoritmo César en el carácter seleccionado
    $nipEncriptado = encriptarNIP($nip, $indexAleatorio);

    // Insertar datos en la base de datos
    $sql = "INSERT INTO usuarios (usuario, contrasena, nip) VALUES ('$usuario', '$contrasenaEncriptada', '$nipEncriptado')";

    if ($conn->query($sql) === TRUE) {
        echo "Usuario registrado exitosamente.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();

function obtenerDesplazamiento($caracterAleatorio) {
    if (preg_match('/\d/', $caracterAleatorio)) {
        return intval($caracterAleatorio);  // Retorna un dígito del NIP
    } else {
        return ord($caracterAleatorio) - ord('a');  // Retorna el valor ASCII de la letra
    }
}

function encriptarContrasena($contrasena, $desplazamiento) {
    $resultado = '';
    
    for ($i = 0; $i < strlen($contrasena); $i++) {
        $codigo = ord($contrasena[$i]);

        // Desplazamiento para letras minúsculas
        if ($codigo >= 97 && $codigo <= 122) { // a-z
            $resultado .= chr((($codigo - 97 + $desplazamiento) % 26) + 97);
        }
        // Desplazamiento para letras mayúsculas
        elseif ($codigo >= 65 && $codigo <= 90) { // A-Z
            $resultado .= chr((($codigo - 65 + $desplazamiento) % 26) + 65);
        }
        // Desplazamiento para números
        elseif ($codigo >= 48 && $codigo <= 57) { // 0-9
            $resultado .= chr((($codigo - 48 + $desplazamiento) % 10) + 48);
        }
        // Desplazamiento para caracteres especiales
        else {
            // Suponemos que queremos que el desplazamiento se aplique solo a números y letras
            $resultado .= chr($codigo + $desplazamiento); // Desplazar los caracteres especiales
        }
    }
    return $resultado;
}

function encriptarNIP($nip, $indexAleatorio) {
    $caracter = $nip[$indexAleatorio];
    $codigo = ord($caracter);

    // Desplazamiento César por 3 posiciones
    $desplazamientoCesar = 3;

    if (preg_match('/[a-zA-Z]/', $caracter)) {
        // Encriptar el carácter usando el algoritmo César
        $encriptado = chr((($codigo - 65 + $desplazamientoCesar) % 26) + 65);
        return substr_replace($nip, $encriptado, $indexAleatorio, 1);
    } elseif (preg_match('/\d/', $caracter)) {
        // Si es un número, también se encripta con César
        $encriptado = chr((($codigo - 48 + $desplazamientoCesar) % 10) + 48);
        return substr_replace($nip, $encriptado, $indexAleatorio, 1);
    }
    return $nip;
}
?>
